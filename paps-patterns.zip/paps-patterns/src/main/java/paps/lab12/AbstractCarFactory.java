package paps.lab12;

public interface AbstractCarFactory {
    Vehicle createVehicle();
}
