package paps.lab13;

public class Proxy {
    public static void main(String [] args) {

    }
}
