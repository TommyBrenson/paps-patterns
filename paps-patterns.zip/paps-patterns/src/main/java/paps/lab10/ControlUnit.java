package paps.lab10;

public interface ControlUnit {
    void startEngine();
    void stopEngine();
}
